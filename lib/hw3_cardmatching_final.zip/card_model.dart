class CardModel {
  final String front;
  bool isFaceUp;

  CardModel({required this.front, this.isFaceUp = false});
}
